#!/system/bin/sh

replace() {
    for file_path in $1; do
        if [ -f $file_path ]; then
            file_dir=$(dirname $file_path)
            module_dir="${MODPATH}/${file_dir}/"
            if [ ! -d $module_dir ]; then
                mkdir -p $module_dir
            fi
            echo "" > "${MODPATH}/${file_path}"
            ui_print "Replace ${file_path}"
        fi
    done
}

ui_print "- Replacing thermal files."

if [ ! -n "$KSU_VER" ]; then
    # MediaTek Perf Service Config
    replace "/system/vendor/etc/power_app_cfg.xml"
    replace "/system/vendor/etc/powercontable.xml"
    replace "/system/vendor/etc/powerscntbl.cfg"
    replace "/system/vendor/etc/powerscntbl.xml"

    # Qualcomm Perf Service Config
    replace "/system/vendor/etc/perf/perfboostsconfig.xml"
    replace "/system/vendor/etc/powerhint.xml"
    replace "/system/vendor/etc/powerhint.json"

    # MIUI Perf Service Application
    replace "/system/app/MiuiDaemon/MiuiDaemon.apk"
    replace "/system/system_ext/app/MiuiDaemon/MiuiDaemon.apk"
    replace "/system/app/Joyose/Joyose.apk"

    # OPPO HORAE Service Config
    replace "/system/system_ext/etc/horae/horae*.conf"
    replace "/system/system_ext/etc/sys_bad_battery_config.xml"

    # Android Thermal Daemon
    replace "/system/bin/*thermal*"
    replace "/system/xbin/*thermal*"
    replace "/system/vendor/bin/*thermal*"
    replace "/system/system_ext/bin/*thermal*"
    replace "/system/product/bin/*thermal*"

    # Android Thermal Config
    replace "/system/etc/*thermal*.conf"
    replace "/system/vendor/etc/*thermal*.conf"

    # MediaTek Thermal Config
    replace "/system/etc/.tp/*"
    replace "/system/vendor/etc/.tp/*"
    replace "/system/vendor/etc/thermal/*"

    # Android Thermal Framework
    replace "/system/framework/*thermal*"
    replace "/system/framework/arm/*thermal*"
    replace "/system/framework/arm64/*thermal*"
    replace "/system/framework/oat/arm/*thermal*"
    replace "/system/framework/oat/arm64/*thermal*"

    # Android Thermal Library
    replace "/system/lib/thermal.*.so"
    replace "/system/lib64/thermal.*.so"
    replace "/system/lib/hw/thermal.*.so"
    replace "/system/lib64/hw/thermal.*.so"
    replace "/system/vendor/lib/thermal.*.so"
    replace "/system/vendor/lib64/thermal.*.so"
    replace "/system/vendor/lib/hw/thermal.*.so"
    replace "/system/vendor/lib64/hw/thermal.*.so"

    # Android Thermal Kernel Module
    # May Cause System Crash.
    # replace "/system/vendor/lib/modules/*thermal*.ko"
else
    # Support KernelSU
    ui_print "- Detected KernelSU ${KSU_VER}."

    # MediaTek Perf Service Config
    replace "/vendor/etc/power_app_cfg.xml"
    replace "/vendor/etc/powercontable.xml"
    replace "/vendor/etc/powerscntbl.cfg"
    replace "/vendor/etc/powerscntbl.xml"

    # Qualcomm Perf Service Config
    replace "/vendor/etc/perf/perfboostsconfig.xml"
    replace "/vendor/etc/powerhint.xml"
    replace "/vendor/etc/powerhint.json"

    # MIUI Perf Service Application
    replace "/system/app/MiuiDaemon/MiuiDaemon.apk"
    replace "/system_ext/app/MiuiDaemon/MiuiDaemon.apk"
    replace "/system/app/Joyose/Joyose.apk"

    # OPPO HORAE Service Config
    replace "/system_ext/etc/horae/horae*.conf"
    replace "/system_ext/etc/sys_bad_battery_config.xml"

    # Android Thermal Daemon
    replace "/system/bin/*thermal*"
    replace "/system/xbin/*thermal*"
    replace "/vendor/bin/*thermal*"
    replace "/system_ext/bin/*thermal*"
    replace "/product/bin/*thermal*"

    # Android Thermal Config
    replace "/system/etc/*thermal*.conf"
    replace "/vendor/etc/*thermal*.conf"

    # MediaTek Thermal Config
    replace "/system/etc/.tp/*"
    replace "/vendor/etc/.tp/*"
    replace "/vendor/etc/thermal/*"

    # Android Thermal Framework
    replace "/system/framework/*thermal*"
    replace "/system/framework/arm/*thermal*"
    replace "/system/framework/arm64/*thermal*"
    replace "/system/framework/oat/arm/*thermal*"
    replace "/system/framework/oat/arm64/*thermal*"

    # Android Thermal Library
    replace "/system/lib/thermal.*.so"
    replace "/system/lib64/thermal.*.so"
    replace "/system/lib/hw/thermal.*.so"
    replace "/system/lib64/hw/thermal.*.so"
    replace "/vendor/lib/thermal.*.so"
    replace "/vendor/lib64/thermal.*.so"
    replace "/vendor/lib/hw/thermal.*.so"
    replace "/vendor/lib64/hw/thermal.*.so"

    # Android Thermal Kernel Module
    # May Cause System Crash.
    # replace "/vendor/lib/modules/*thermal*.ko"
fi

ui_print "- Thermal files replaced."

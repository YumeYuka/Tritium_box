#!/system/bin/sh
BASE_DIR=$(dirname "$0")

while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done

"${BASE_DIR}/bin/bpfLoader" "${BASE_DIR}/bin/CuUtilMonitor.o" > "${BASE_DIR}/load.log"

"${BASE_DIR}/bin/bpfAttacher" \
--program "CuUtilMonitor" \
--add-tracepoint "sched/sched_switch" \
--log "${BASE_DIR}/attach.log"

sleep 30

if [ -f "${BASE_DIR}/.system_crashed" ]; then
	rm -f "${BASE_DIR}/.system_crashed"
fi

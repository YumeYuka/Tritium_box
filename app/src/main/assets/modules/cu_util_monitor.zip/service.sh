#!/system/bin/sh
BASE_DIR=$(dirname "$0")

bpfloader 2>/dev/null

sleep 5
dmesg | grep "LibBpfLoader" > "${BASE_DIR}/load.log"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done

bpfAttacher \
--program "CuUtilMonitor" \
--add-tracepoint "sched/sched_switch" \
--log "${BASE_DIR}/attach.log"

sleep 30

if [ -f "${BASE_DIR}/.system_crashed" ]; then
	rm -f "${BASE_DIR}/.system_crashed"
fi
